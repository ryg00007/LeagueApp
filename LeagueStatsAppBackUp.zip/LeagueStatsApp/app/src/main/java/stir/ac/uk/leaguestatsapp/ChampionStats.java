package stir.ac.uk.leaguestatsapp;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ChampionStats extends Activity {
    private Context context = ChampionStats.this;
    private ImageView champSquare;
    private TextView championName;
    private TextView winRate;
    private String data = "";
    private String champName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_champion_stats);
        String passedChampionName = getIntent().getStringExtra("PASSED_CHAMPNAME_NAME");
        new getChampionInfoFromDB().execute(passedChampionName);
    }

    private class getChampionInfoFromDB extends AsyncTask<String, Boolean, JSONObject> {

        protected void onPreExecute() {
            championName = findViewById(R.id.cnameTextView);
            winRate = findViewById(R.id.winRateTextView);
            champSquare = findViewById(R.id.champSquare);
        }

        protected JSONObject doInBackground(String... args) {
                return getChampionInfo(args[0]);

        }

        protected void onPostExecute(JSONObject response) {
            displayInformationFromJSON(response);
            String champImg = champName;
            champImg = champImg.toLowerCase();
            System.out.println(champImg);
            int intCurrImageResourceID = context.getResources().getIdentifier(champImg, "drawable", context.getPackageName());
            System.out.println(intCurrImageResourceID);
            champSquare.setImageResource(intCurrImageResourceID);
        }
    }

    private JSONObject getChampionInfo(String passedChampionName) {
        String passedChampName = passedChampionName;
        String link = "https://lamp0.cs.stir.ac.uk/~rgi/MobileApp/index.php?championName="+passedChampName;
        System.out.println("Champion Name:" +passedChampName);
        try {
            URL url = new URL(link);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while(line != null){
                line = bufferedReader.readLine();
                data = data + line;
            }

            JSONArray JA = new JSONArray(data);
            for(int i = 0; i< JA.length(); i++){
                JSONObject JO = (JSONObject) JA.get(i);
                return JO;
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return null;
    }

    private void displayInformationFromJSON(JSONObject jo) {
        try {
            champName = ""+ jo.get("Name");
            String championID = "" + jo.get("ID");
            String championWins = "" + jo.get("Wins");
            String championsLosses = "" + jo.get("Losses");
            championName.setText(""+champName);
            winRate.setText("Wins: "+ championWins + " Losses: "+ championsLosses);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
