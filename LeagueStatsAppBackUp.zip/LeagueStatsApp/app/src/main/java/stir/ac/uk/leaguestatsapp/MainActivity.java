package stir.ac.uk.leaguestatsapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {

    private String APIKey = "";
    private EditText editText;
    private Button LookUpButton;
    private Button championButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configureStatScreenButton();
        configureChampionButton();
    }

    @Override
    public void onResume(){
        super.onResume();

    }

    private void configureStatScreenButton() {
        LookUpButton = findViewById(R.id.LookUpButton);
        editText = findViewById(R.id.editText);
        LookUpButton.setEnabled(false);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.toString().length()<1) {
                    LookUpButton.setEnabled(false);
                } else {
                    LookUpButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        LookUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String SummonerName = editText.getText().toString();
                Intent intent = new Intent(MainActivity.this, StatScreen.class);
                intent.putExtra("PASSED_SUM_NAME", SummonerName);
                startActivity(intent);
            }
        });
    }

    private void configureChampionButton() {
        championButton = findViewById(R.id.championButton);
        championButton.setEnabled(true);
        championButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ChampionView.class);
                startActivity(intent);
            }
        });
    }


}
