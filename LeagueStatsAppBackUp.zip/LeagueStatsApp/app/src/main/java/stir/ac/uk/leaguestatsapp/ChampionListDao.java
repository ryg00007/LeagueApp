package stir.ac.uk.leaguestatsapp;



import java.util.List;

import androidx.room.Dao;
import androidx.room.Query;

@Dao
public interface ChampionListDao {
    @Query("SELECT * FROM ChampionList")
    List<ChampionList> getAll();

    @Query("SELECT Name FROM ChampionList")
    List<ChampionList> loadAllByName();
}
