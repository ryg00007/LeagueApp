package stir.ac.uk.leaguestatsapp;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import net.rithms.riot.api.ApiConfig;
import net.rithms.riot.api.RiotApi;
import net.rithms.riot.api.RiotApiException;
import net.rithms.riot.api.endpoints.league.dto.LeaguePosition;
import net.rithms.riot.api.endpoints.match.dto.MatchList;
import net.rithms.riot.api.endpoints.summoner.dto.Summoner;
import net.rithms.riot.constant.Platform;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class StatScreen extends AppCompatActivity {

    private Context context = StatScreen.this;
    private String passedSummonerName;
    private Summoner summoner;
    private MatchList matchList;
    private TextView SummonerName;
    private TextView SummonerLevel;
    private TextView Rank;
    private TextView WinLoss;
    private TextView WinPercent;
    private TextView Last10;
    private ImageView ProfileIcon;
    private ImageView RankIcon;
    private ImageView Game1;
    private ImageView Game2;
    private ImageView Game3;
    private ImageView Game4;
    private ImageView Game5;
    private ImageView Game6;
    private ImageView Game7;
    private ImageView Game8;
    private ImageView Game9;
    private ImageView Game10;
    private ProgressBar WinRateBar;
    private ProgressBar netLoadBar;
    private List<LeaguePosition> rankedGameModeList;
    private String summonerName;
    private int iconNo;
    private int levelNo;
    private String accountID;
    private String summonerID;
    private int wins;
    private int losses;
    private float gamesPlayed;
    private float winRate;
    private int winPercent;
    private int resID;
    private final String API_KEY = "RGAPI-7eb5c4e8-1f61-4841-92c7-5efadaf919b5";
    private ApiConfig config = new ApiConfig().setKey(API_KEY);
    private String rank;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stat_screen);
        passedSummonerName = getIntent().getStringExtra("PASSED_SUM_NAME");
        netLoadBar = findViewById(R.id.netloadProgressBar);
        SummonerName = findViewById(R.id.SummonerName);
        SummonerLevel = findViewById(R.id.SummonerLevel);
        ProfileIcon = findViewById(R.id.ProfileIcon);
        RankIcon = findViewById(R.id.rankImageView);
        WinLoss = findViewById(R.id.winsTextView);
        WinRateBar = findViewById(R.id.winrateBar);
        WinPercent = findViewById(R.id.winPercentTextView);
        Rank = findViewById(R.id.rankTextView);
        Last10 = findViewById(R.id.last10TextView);


        Game1 = findViewById(R.id.imageView1);
        Game2 = findViewById(R.id.imageView2);
        Game3 = findViewById(R.id.imageView3);
        Game4 = findViewById(R.id.imageView4);
        Game5 = findViewById(R.id.imageView5);
        Game6 = findViewById(R.id.imageView6);
        Game7 = findViewById(R.id.imageView7);
        Game8 = findViewById(R.id.imageView8);
        Game9 = findViewById(R.id.imageView9);
        Game10 = findViewById(R.id.imageView10);


        SummonerName.setVisibility(View.INVISIBLE);
        SummonerLevel.setVisibility(View.INVISIBLE);
        ProfileIcon.setVisibility(View.INVISIBLE);
        RankIcon.setVisibility(View.INVISIBLE);
        WinLoss.setVisibility(View.INVISIBLE);
        WinRateBar.setVisibility(View.INVISIBLE);
        WinPercent.setVisibility(View.INVISIBLE);
        Rank.setVisibility(View.INVISIBLE);
        Last10.setVisibility(View.INVISIBLE);

        new getBasicSummonerInternetTask().execute(passedSummonerName);
    }

    private class getBasicSummonerInternetTask extends AsyncTask<String, Boolean, Boolean> {

        protected void onPreExecute() {

        }

        protected Boolean doInBackground(String... args) {
            try {
                getSummonerInformation(args[0]);
                return true;
            } catch (RiotApiException e) {

                Log.d("error:", ""+e);
                return false;
            }
        }

        protected void onPostExecute(Boolean response) {

            if(response) {
                summonerInformationText();
                leagueInformationText();
                last10GameText();
                netLoadBar.setVisibility(View.INVISIBLE);
                RankIcon.setVisibility(View.VISIBLE);
                Last10.setVisibility(View.VISIBLE);
            } else {
                netLoadBar.setVisibility(View.INVISIBLE);
                Last10.setText("ERROR");
                Last10.setVisibility(View.VISIBLE);
            }

        }
    }

    private void getSummonerInformation(String summonerName) throws RiotApiException {
        RiotApi api = new RiotApi(config);
        summoner = api.getSummonerByName(Platform.EUW, summonerName);
        this.summonerName = summonerName;
        iconNo = summoner.getProfileIconId();
        levelNo = summoner.getSummonerLevel();
        summonerID = summoner.getAccountId();
        accountID = summoner.getId();

        //Proceed to get information on where the player has placed.
        getLeagueInformation(api, accountID, summonerID);
    }

    private void getLeagueInformation(RiotApi api, String accountID, String summonerID) throws RiotApiException{
        Set<LeaguePosition> leaguePosition;
        leaguePosition = api.getLeaguePositionsBySummonerId(Platform.EUW, accountID);

        // Index 0 is Ranked Solo/Duo, Index 1 is Flex.
        if(!leaguePosition.isEmpty()) {
            rankedGameModeList = new ArrayList<>();
            rankedGameModeList.addAll(leaguePosition);
            wins = rankedGameModeList.get(0).getWins();
            losses = rankedGameModeList.get(0).getLosses();
            rank = rankedGameModeList.get(0).getTier();
            System.out.println("Rank is:" +rank);
        } else {
            wins = 0;
            losses = 0;
            rank = "UNRANKED";
        }
        //rank = rankedGameModeList.get(0).getLeagueName();
        //Proceed to get a short match history from the player.
        getLast10Games(api, summonerID);
    }

    private void getLast10Games(RiotApi api, String summonerID) throws RiotApiException{
        Set<Integer> queue = new HashSet<Integer>();
        queue.add(420);
        Set<Integer> season = new HashSet<Integer>();
        season.add(13);
        //Queue 420 is Ranked Solo Queue, Season 13 is 2019 Season.
        matchList = api.getMatchListByAccountId(Platform.EUW, summonerID, null, null, null, -1, -1, -1, 10);
    }


    public void summonerInformationText() {
        int intCurrImageResourceID = context.getResources().getIdentifier("emblem_"+ rank.toLowerCase(), "drawable", context.getPackageName());
        RankIcon.setImageResource(intCurrImageResourceID);
        Rank.setText(rank);
        SummonerName.setText(""  + summonerName );
        SummonerLevel.setText("Level: " + levelNo);
        String url = "https://ddragon.leagueoflegends.com/cdn/8.24.1/img/profileicon/" + iconNo + ".png";
        Glide
                .with(context)
                .load(url)
                .apply(RequestOptions.circleCropTransform())
                .into(ProfileIcon);


        SummonerName.setVisibility(View.VISIBLE);
        SummonerLevel.setVisibility(View.VISIBLE);
        ProfileIcon.setVisibility(View.VISIBLE);
    }

    public void leagueInformationText() {

        WinLoss.setText("W: " + wins + " / L: " + losses);
        WinRateBar.setMax(100);
        float GamesPlayed = wins + losses;
        winRate = (wins / GamesPlayed) * 100;
        winPercent = Math.round(winRate);
        System.out.println(winPercent);
        WinRateBar.setProgress(winPercent);
        if(winPercent >= 50){
            WinRateBar.getProgressDrawable().setColorFilter(Color.GREEN, PorterDuff.Mode.SRC_IN);
        } else {
            WinRateBar.getProgressDrawable().setColorFilter(Color.RED, PorterDuff.Mode.SRC_IN);
        }
        WinPercent.setText("WIN PERCENT " + winPercent + "%");


        WinLoss.setVisibility(View.VISIBLE);
        WinRateBar.setVisibility(View.VISIBLE);
        WinPercent.setVisibility(View.VISIBLE);
        Rank.setVisibility(View.VISIBLE);
    }

    public void last10GameText() {
        int matchListSize = matchList.getMatches().size();
        for (int i = 1; i<=matchListSize; i++){
            switch(i){
                case 1:
                    Game1.setVisibility(View.VISIBLE);
                    System.out.println("Played Champion: " +matchList.getMatches().get(0).getChampion());
                    break;
                case 2:
                    Game2.setVisibility(View.VISIBLE);
                    break;
                case 3:
                    Game3.setVisibility(View.VISIBLE);
                    break;
                case 4:
                    Game4.setVisibility(View.VISIBLE);
                    break;
                case 5:
                    Game5.setVisibility(View.VISIBLE);
                    break;
                case 6:
                    Game6.setVisibility(View.VISIBLE);
                    break;
                case 7:
                    Game7.setVisibility(View.VISIBLE);
                    break;
                case 8:
                    Game8.setVisibility(View.VISIBLE);
                    break;
                case 9:
                    Game9.setVisibility(View.VISIBLE);
                    break;
                case 10:
                    Game10.setVisibility(View.VISIBLE);
                    break;

            }

        }
    }
}

