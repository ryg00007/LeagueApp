package stir.ac.uk.leaguestatsapp;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;

public class ChampionView extends Activity {

    private ArrayList<String> mName = new ArrayList<>();
    private ArrayList<String> mImage = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_champion_view);
        initImageBitmaps();

    }

    private void initImageBitmaps(){
        mName.add("Aatrox");
        mName.add("Ahri");
        mName.add("Akali");
        mName.add("Alistar");
        mName.add("Amumu");
        mName.add("Anivia");
        mName.add("Annie");
        mName.add("Ashe");
        mName.add("AurelionSol");
        mName.add("Azir");
        mName.add("Bard");
        mName.add("Blitzcrank");
        mName.add("Brand");
        mName.add("Braum");
        mName.add("Caitlyn");
        mName.add("Camille");
        mName.add("Cassiopeia");
        mName.add("Chogath");
        mName.add("Corki");
        mName.add("Darius");
        mName.add("Diana");
        mName.add("Draven");
        mName.add("DrMundo");
        mName.add("Ekko");
        mName.add("Elise");
        mName.add("Evelynn");
        mName.add("Ezreal");
        mName.add("FiddleSticks");
        mName.add("Fiora");
        mName.add("Fizz");
        mName.add("Galio");
        mName.add("Gangplank");
        mName.add("Garen");
        mName.add("Gnar");
        mName.add("Gragas");
        mName.add("Graves");
        mName.add("Hecarim");
        mName.add("Heimerdinger");
        mName.add("Illaoi");
        mName.add("Irelia");
        mName.add("Ivern");
        mName.add("Janna");
        mName.add("JarvanIV");
        mName.add("Jax");
        mName.add("Jayce");
        mName.add("Jhin");
        mName.add("Jinx");
        mName.add("Kalista");
        mName.add("Karma");
        mName.add("Karthus");
        mName.add("Kassadin");
        mName.add("Katarina");
        mName.add("Kayle");
        mName.add("Kennen");
        mName.add("Khazix");
        mName.add("Kindred");
        mName.add("Kled");
        mName.add("KogMaw");
        mName.add("Leblanc");
        mName.add("LeeSin");
        mName.add("Leona");
        mName.add("Lissandra");
        mName.add("Lucian");
        mName.add("Lulu");
        mName.add("Lux");
        mName.add("Malphite");
        mName.add("Malzahar");
        mName.add("Maokai");
        mName.add("MasterYi");
        mName.add("MissFortune");
        mName.add("MonkeyKing");
        mName.add("Mordekaiser");
        mName.add("Morgana");
        mName.add("Nami");
        mName.add("Nasus");
        mName.add("Nautilus");
        mName.add("Nidalee");
        mName.add("Nocturne");
        mName.add("Nunu");
        mName.add("Olaf");
        mName.add("Orianna");
        mName.add("Pantheon");
        mName.add("Poppy");
        mName.add("Quinn");
        mName.add("Rammus");
        mName.add("RekSai");
        mName.add("Renekton");
        mName.add("Rengar");
        mName.add("Riven");
        mName.add("Rumble");
        mName.add("Ryze");
        mName.add("Sejuani");
        mName.add("Shaco");
        mName.add("Shen");
        mName.add("Shyvana");
        mName.add("Singed");
        mName.add("Sion");
        mName.add("Sivir");
        mName.add("Skarner");
        mName.add("Sona");
        mName.add("Soraka");
        mName.add("Swain");
        mName.add("Syndra");
        mName.add("TahmKench");
        mName.add("Taliyah");
        mName.add("Talon");
        mName.add("Taric");
        mName.add("Teemo");
        mName.add("Thresh");
        mName.add("Tristana");
        mName.add("Trundle");
        mName.add("Tryndamere");
        mName.add("TwistedFate");
        mName.add("Twitch");
        mName.add("Udyr");
        mName.add("Urgot");
        mName.add("Varus");
        mName.add("Vayne");
        mName.add("Veigar");
        mName.add("Velkoz");
        mName.add("Vi");
        mName.add("Viktor");
        mName.add("Vladimir");
        mName.add("Volibear");
        mName.add("Warwick");
        mName.add("Xerath");
        mName.add("XinZhao");
        mName.add("Yasuo");
        mName.add("Yorick");
        mName.add("Zac");
        mName.add("Zed");
        mName.add("Ziggs");
        mName.add("Zilean");
        mName.add("Zyra");
        mImage = (ArrayList<String>) mName.clone();
        initRecyclerView();
    }

    private void initRecyclerView(){
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(mName, mImage, this );
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 4));
    }
}
